﻿using System.ComponentModel.DataAnnotations;

namespace Deltek.CRUD.API.Model
{
    public class Contact
    {
        [Key]
        public int ContactId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string MobileNumber { get; set; }
        public string Address { get; set; }
    }
}
