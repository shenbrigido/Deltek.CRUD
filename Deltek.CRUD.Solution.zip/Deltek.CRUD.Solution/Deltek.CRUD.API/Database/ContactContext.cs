﻿using Deltek.CRUD.API.Model;
using Microsoft.EntityFrameworkCore;

namespace Deltek.CRUD.API.Database
{
    public class ContactContext : DbContext
    {
        public ContactContext(DbContextOptions<ContactContext> options)
            : base(options)
        {
        
        }
        public DbSet<Contact> Contacts { get; set; }
    }
}
