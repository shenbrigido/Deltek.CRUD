﻿using Deltek.CRUD.API.Database;
using Deltek.CRUD.API.Model;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Diagnostics;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Deltek.CRUD.API.Repositories
{
    public class ContactRepository : IContactRepository
    {
        private ContactContext context;

        public ContactRepository(ContactContext context)
        {
            this.context = context;
        }

        public async Task<IEnumerable<Contact>> GetAllContactAsync()
        {
            return await context.Contacts.ToListAsync();
        }

        public async Task<int> AddContactAsync(Contact contact)
        {
            context.Contacts.Add(contact);
            return await context.SaveChangesAsync();
        }

        public async Task<int> UpdateContactAsync(Contact contact)
        {
            var data = context.Contacts.FirstOrDefault(item => item.ContactId == contact.ContactId);
            if (data != null)
            {
                context.Entry(data).State = EntityState.Detached;
                context.Entry(contact).State = EntityState.Modified;
                return await context.SaveChangesAsync();
            }
            else
            {
                return 1;
            }
        }
        public async Task<int> RemoveContactAsync(Contact contact)
        {
            var people = context.Contacts.Find(contact.ContactId);
            context.Contacts.Remove(people);
            return await context.SaveChangesAsync();
        }
    }
}
