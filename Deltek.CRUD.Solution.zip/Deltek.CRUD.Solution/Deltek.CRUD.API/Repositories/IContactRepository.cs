﻿using Deltek.CRUD.API.Model;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Deltek.CRUD.API.Repositories
{
    public interface IContactRepository
    {

        Task<IEnumerable<Contact>> GetAllContactAsync();
        Task<int> AddContactAsync(Contact contact);
        Task<int> UpdateContactAsync (Contact contact);
        Task<int> RemoveContactAsync(Contact contact);
    }
}