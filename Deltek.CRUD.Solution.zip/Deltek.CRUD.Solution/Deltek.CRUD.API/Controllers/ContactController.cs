﻿using Deltek.CRUD.API.Model;
using Deltek.CRUD.API.Services;
using EnsureThat;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Deltek.CRUD.API.Controllers
{
    [ApiController]
    [Route("[controller]")]
    [Authorize(Policy = "StakeHolder")]
    public class ContactController
    {
        private readonly IContactsService contactService;
        public ContactController(IContactsService contactService)
        {
            this.contactService = contactService;
        }

        [HttpGet("GetAllContact")]
        public async Task<IEnumerable<Contact>> GetAllContact()
        {
            return await contactService.GetAllContactAsync();
        }

        [HttpPost("AddContact")]
        public async Task<int> AddContact(Contact contact)
        {
            EnsureArg.IsNotNull(contact, "contact");
            return await contactService.AddContact(contact);
        }
        [HttpPost("UpdateContact")]
        public async Task<int> UpdateContact(Contact contact)
        {
            EnsureArg.IsNotNull(contact, "contact");
            return await contactService.UpdateContact(contact);
        }
        [HttpDelete("RemoveContact")]
        public async Task<int> RemoveContact(Contact contact)
        {
            EnsureArg.IsNotNull(contact, "contact");
            return await contactService.RemoveContact(contact);
        }
    }
}
