﻿using Deltek.CRUD.API.Model;
using Deltek.CRUD.API.Repositories;
using System.Collections;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Deltek.CRUD.API.Services
{
    public class ContactsService : IContactsService
    {
        IContactRepository contactRepository;
        public ContactsService(IContactRepository contactRepository)
        {
            this.contactRepository = contactRepository;
        }
        public async Task<IEnumerable<Contact>> GetAllContactAsync()
        {
            return await contactRepository.GetAllContactAsync();
        }
        public async Task<int> AddContact(Contact contact)
        {
            return await contactRepository.AddContactAsync(contact);
        }
        public async Task<int> UpdateContact(Contact contact)
        {
            return await contactRepository.UpdateContactAsync(contact);
        }

        public async Task<int> RemoveContact(Contact contact)
        {
            return await contactRepository.RemoveContactAsync(contact);
        }
    }
}
