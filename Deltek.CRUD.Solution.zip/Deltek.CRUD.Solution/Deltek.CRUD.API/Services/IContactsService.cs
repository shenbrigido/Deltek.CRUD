﻿using Deltek.CRUD.API.Model;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Deltek.CRUD.API.Services
{
    public interface IContactsService
    {
        Task<IEnumerable<Contact>> GetAllContactAsync();   
        Task<int> AddContact(Contact contact);
        Task<int> UpdateContact(Contact contact);
        Task<int> RemoveContact(Contact contact);
    }
}