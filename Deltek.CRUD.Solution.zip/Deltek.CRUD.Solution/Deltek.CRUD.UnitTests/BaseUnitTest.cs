using Deltek.CRUD.API.Controllers;
using Deltek.CRUD.API.Repositories;
using Deltek.CRUD.API.Services;
using Deltek.CRUD.UnitTests.Mocks;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Deltek.CRUD.UnitTests
{
    [TestClass]
    public abstract class BaseUnitTest
    {
        public ServiceProvider ContainerService;

        [TestInitialize]
        public void Setup()
        {
            var services = new ServiceCollection();

            services.AddScoped(p => MockContactContext.CreateInMemoryContextWithData(System.Guid.NewGuid().ToString()));
            services.AddScoped<ContactController>();
            services.AddTransient<IContactRepository, ContactRepository>();
            services.AddTransient<IContactsService, ContactsService>();

            ContainerService = services.BuildServiceProvider();

        }
        [TestCleanup]
        public void Cleanup()
        {

        }
     
    }
}
