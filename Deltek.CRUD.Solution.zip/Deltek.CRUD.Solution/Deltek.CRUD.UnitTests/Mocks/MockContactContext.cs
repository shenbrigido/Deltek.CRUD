﻿using Deltek.CRUD.API.Database;
using Deltek.CRUD.API.Model;
using Microsoft.EntityFrameworkCore;


namespace Deltek.CRUD.UnitTests.Mocks
{
    public class MockContactContext
    {
        public static ContactContext CreateInMemoryContextWithData(string dbname)
        {
            DbContextOptions<ContactContext> options = new DbContextOptionsBuilder<ContactContext>()
                .UseInMemoryDatabase(dbname)
                .Options;

            var context = new ContactContext(options);

            context.Contacts.Add(
                new Contact
                {
                    ContactId = 1,
                    FirstName = "John",
                    LastName = "Smith",
                    MobileNumber = "9866786976",
                    Address = "Manila, PH"
                });
            context.SaveChanges();
            return context;
        }
    }
}
