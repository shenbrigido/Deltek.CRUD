﻿using Deltek.CRUD.API.Controllers;
using Deltek.CRUD.API.Model;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Deltek.CRUD.UnitTests
{
    [TestClass]
    public class UnitTest_ContactControllerTest : BaseUnitTest
    {
        [TestMethod]
        public async Task Verify_ContactControllerTest_GetAllContact_IsNotNull()
        {
            var controller = ActivatorUtilities.CreateInstance<ContactController>(ContainerService);

            var response = await controller.GetAllContact();

            Assert.IsNotNull(response);
        }

        [TestMethod]
        public async Task Verify_ContactControllerTest_AddContact_IsNotNull()
        {
            var controller = ActivatorUtilities.CreateInstance<ContactController>(ContainerService);
            var addContact = new Contact
            {
                FirstName = "Justine",
                LastName = "Smith",
                MobileNumber = "98667976",
                Address = "Manila, PH"
            };
            var result = await controller.AddContact(addContact);
         
            Assert.IsNotNull(result);
        }

        [TestMethod]
        public async Task Verify_ContactControllerTest_UpdateContact_IsNotNull()
        {
            var controller = ActivatorUtilities.CreateInstance<ContactController>(ContainerService);
            var updatedContact = new Contact()
            {
                ContactId = 1,
                FirstName = "Updated Contact First Name",
                LastName = "Updated Contact Last Name",
                MobileNumber = "9866786976",
                Address = "Manila, PH"
            };
            var result = await controller.UpdateContact(updatedContact);
            Assert.IsNotNull(result);
        }

        [TestMethod]
        public async Task Verify_ContactControllerTest_RemoveContact_IsNotNull()
        {
            var controller = ActivatorUtilities.CreateInstance<ContactController>(ContainerService);

            var addContact = new Contact
            {
                ContactId = 1,
            };
            var result = await controller.RemoveContact(addContact);
            Assert.IsNotNull(result);
        }
    }
}
