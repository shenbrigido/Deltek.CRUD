﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Deltek.CRUD.Client.Console
{
    public class Contact
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string MobileNumber { get; set; }
        public string Address { get; set; }
    }
}
