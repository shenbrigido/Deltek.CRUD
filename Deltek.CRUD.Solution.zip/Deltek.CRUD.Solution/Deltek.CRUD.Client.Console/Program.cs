﻿
using Deltek.CRUD.Client.Console;
using IdentityModel.Client;
using Newtonsoft.Json;
using System;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace Deltek.CRUD
{
    class Program
    {
        public static void Main(string[] args) => MainAsync().GetAwaiter().GetResult();

        private static async Task MainAsync()
        {
            var token = await GetAccessToken();
            var contactAdded = await AddContactAsync(token);
            var contacts = await GetAllContactsAsync(token);
            Console.ReadLine();
        }

        private async static Task<string> GetAccessToken()
        {
            var client = new HttpClient();
            var disco = await DiscoveryClient.GetAsync("http://localhost:5000/");
            var tokenClient = new TokenClient(disco.TokenEndpoint, "client", "secret");
            var tokenResponse = await tokenClient.RequestResourceOwnerPasswordAsync("alice", "Pass123$", "DeltekCRUDApi");
            return tokenResponse.AccessToken;
        }

        public async static Task<HttpResponseMessage> GetAllContactsAsync(string token)
        {
            var client = new HttpClient();
            client.SetBearerToken(token);
            return await client.GetAsync("http://localhost:5001/contact/GetAllContact");
        }

        public async static Task<HttpResponseMessage> AddContactAsync(string token)
        {
            var client = new HttpClient();
            client.SetBearerToken(token);
            var contact = new Contact()
            {
                FirstName = "Jeff",
                LastName = "Gandy",
                MobileNumber = "0955553535",
                Address = "Makati Metro Manila"
            };
            return await client.PostAsync("http://localhost:5001/contact/AddContact", 
                new StringContent(JsonConvert.SerializeObject(contact), Encoding.UTF8, "application/json"));
        }
    }
}
